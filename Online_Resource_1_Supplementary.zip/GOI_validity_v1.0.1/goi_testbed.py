#!/usr/bin/env python3
"""
GOI measurement-validation testbed, v1.0 (frozen).

Deterministic, seeded simulation of a governed payments agent, an authoritative
ledger, a signed telemetry stream, and a telemetry-side Governance Observability
Index (GOI) estimator. Faults are injected into the telemetry path only; the
ledger and the episode labels are never visible to the estimator, except through
the two independent channels named below (gateway control total, ledger sample).

Run:  python3 goi_testbed.py            -> writes results/ (CSV + JSON)
"""
import hashlib
import hmac
import json
import os
import sys
import math
import random
import csv

# ---------------------------------------------------------------- constants
MASTER_SEED = 20261029
LIMIT = 5000.0          # per-action policy limit (monetary units)
BUDGET = 2.0            # timeliness budget, seconds (event -> collector)
SKEW_TOL = 0.25         # tolerated clock skew, seconds
N_ACTIONS = 200         # agent intents per run
N_PAYEES = 40
N_APPROVED = 36
FID_SAMPLE = 40         # ledger records sampled for fidelity reconciliation
I_MIN = 0.5             # integrity floor (foundational GOI proposal)
WINDOW = 30.0           # structuring monitor window, seconds
N_EPISODES = 3          # structuring episodes per run
BAND = 0.8              # structuring rule: >=3 transfers in [BAND*LIMIT, LIMIT] to one payee within WINDOW
SPANS = ("INTENT", "POLICY", "TOOL", "OUTCOME")
SPAN_DT = {"INTENT": 0.00, "POLICY": 0.05, "TOOL": 0.10, "OUTCOME": 0.15}
KEYS = {"k1": b"deployment-key-1-test-only", "k2": b"deployment-key-2-test-only"}

KNOWN = ["F1_drop", "F2_fidelity_bug", "F3_tamper", "F4_delay"]
HELDOUT = ["H1_tail_truncation", "H2_replay", "H3_insider_forgery", "H4_insider_deletion"]
BENIGN = ["B1_retry_duplicates", "B2_async_reorder", "B3_clock_skew", "B4_key_rotation"]
FAMILIES = KNOWN + HELDOUT + BENIGN
SEVERITIES = [0.0, 0.05, 0.10, 0.20, 0.30, 0.45, 0.60]


# ---------------------------------------------------------------- signing
def canon(r):
    return "|".join(str(r[k]) for k in
                    ("run", "aid", "span", "seq", "payee", "amount", "decision", "t_ev", "key_id", "prev"))


def sign(r):
    r["mac"] = hmac.new(KEYS[r["key_id"]], canon(r).encode(), hashlib.sha256).hexdigest()


def mac_ok(r):
    if r["key_id"] not in KEYS:
        return False
    exp = hmac.new(KEYS[r["key_id"]], canon(r).encode(), hashlib.sha256).hexdigest()
    return hmac.compare_digest(exp, r["mac"])


def chain_sign(records, run_id):
    """(Re)sign a stream as the legitimate emitter would: seq order, prev = mac of predecessor."""
    prev = "GENESIS-" + str(run_id)
    for r in sorted(records, key=lambda x: x["seq"]):
        r["prev"] = prev[:16]
        sign(r)
        prev = r["mac"]


# ---------------------------------------------------------------- world
def gen_world(rng, run_id, emitter_fault=None):
    """Ground-truth actions, ledger, structuring episodes and the emitted (signed) telemetry."""
    payees = [f"P{i:02d}" for i in range(N_PAYEES)]
    approved = set(payees[:N_APPROVED])
    weights = [1.0 / (i + 1) ** 0.8 for i in range(N_PAYEES)]   # Zipf-like reuse of payees

    intents = []
    for _ in range(N_ACTIONS):
        p = rng.choices(payees, weights)[0]
        a = round(min(rng.lognormvariate(math.log(900), 1.0), 20000), 2)
        intents.append({"payee": p, "amount": a, "episode": None})
    # structuring episodes: k transfers just under LIMIT to one approved payee, inside WINDOW
    used = set()
    for e in range(N_EPISODES):
        while True:
            start = rng.randrange(5, N_ACTIONS - 25)
            if not any(abs(start - u) < 30 for u in used):
                break
        used.add(start)
        k = rng.choice([3, 4])
        payee = rng.choice(sorted(approved))
        slots = sorted(rng.sample(range(start, start + 18), k))
        for s in slots:
            intents[s] = {"payee": payee, "amount": round(rng.uniform(4000, 4999), 2), "episode": e}

    actions, ledger = [], {}
    for aid, it in enumerate(intents):
        allow = it["amount"] <= LIMIT and it["payee"] in approved
        t = aid * 1.0 + rng.uniform(0, 0.3)
        actions.append({"aid": aid, "t": t, "payee": it["payee"], "amount": it["amount"],
                        "allow": allow, "episode": it["episode"]})
        if allow:
            ledger[aid] = (it["payee"], it["amount"], t)
    episodes = {}
    for a in actions:
        if a["episode"] is not None and a["allow"]:
            episodes.setdefault(a["episode"], []).append(a["aid"])

    # telemetry emission (emitter-side instrumentation bug F2 acts here, before signing)
    bug = {}
    if emitter_fault and emitter_fault[0] == "F2_fidelity_bug":
        for aid in ledger:
            if rng.random() < emitter_fault[1]:
                bug[aid] = rng.choice(["unit", "payee"])
    recs, seq = [], 0
    for a in actions:
        for s in SPANS:
            payee, amount = a["payee"], a["amount"]
            if a["aid"] in bug and s in ("TOOL", "OUTCOME"):
                if bug[a["aid"]] == "unit":
                    amount = round(amount / 100.0, 2)
                else:
                    payee = f"P{(int(payee[1:]) + 1) % N_PAYEES:02d}"
            dec = ("commit" if a["allow"] else "deny") if s in ("POLICY", "OUTCOME") else "-"
            t_ev = round(a["t"] + SPAN_DT[s], 4)
            r = {"run": run_id, "aid": a["aid"], "span": s, "seq": seq, "payee": payee,
                 "amount": amount, "decision": dec, "t_ev": t_ev, "key_id": "k1", "prev": "",
                 "t_arr": round(t_ev + rng.uniform(0.02, 0.04), 4)}
            recs.append(r)
            seq += 1
    chain_sign(recs, run_id)
    return actions, ledger, episodes, recs


# ---------------------------------------------------------------- faults (telemetry path)
def apply_fault(fam, p, recs, rng, run_id, ledger, episodes, donor):
    if p <= 0 or fam == "F2_fidelity_bug":
        return recs
    if fam == "F1_drop":
        return [r for r in recs if rng.random() >= p]
    if fam == "F3_tamper":
        for r in recs:
            if rng.random() < p:
                if rng.random() < 0.5:
                    r["amount"] = round(r["amount"] * rng.uniform(0.5, 1.5), 2)
                else:
                    r["payee"] = f"P{rng.randrange(N_PAYEES):02d}"
        return recs
    if fam == "F4_delay":
        for r in recs:
            if rng.random() < p:
                r["t_arr"] = round(r["t_arr"] + rng.uniform(3, 30), 4)
        return recs
    if fam == "H1_tail_truncation":
        cut = int(len(recs) * (1 - p))
        return sorted(recs, key=lambda x: x["seq"])[:cut]
    if fam == "H2_replay":
        n = int(round(p * len(recs)))
        inj = [dict(r) for r in rng.sample(donor, min(n, len(donor)))]
        for r in inj:                                   # validly signed, wrong context
            r["t_arr"] = round(r["t_ev"] + 0.2, 4)
        return recs + inj
    if fam == "H3_insider_forgery":
        # key holder rewrites committed OUTCOME/TOOL payees, structuring transfers first, re-signs chain
        commits = list(ledger.keys())
        n = int(round(p * len(commits)))
        prio = [a for e in episodes.values() for a in e]
        rest = [a for a in commits if a not in prio]
        rng.shuffle(rest)
        target = set((prio + rest)[:n])
        for r in recs:
            if r["aid"] in target and r["span"] in ("TOOL", "OUTCOME", "INTENT"):
                r["payee"] = f"P{(int(ledger[r['aid']][0][1:]) + 1 + r['aid'] % (N_APPROVED - 1)) % N_APPROVED:02d}"
        chain_sign(recs, run_id)
        return recs
    if fam == "H4_insider_deletion":
        # key holder deletes whole actions (structuring first), renumbers seq, re-signs
        aids = sorted({r["aid"] for r in recs})
        n = int(round(p * len(aids)))
        prio = [a for e in episodes.values() for a in e]
        rest = [a for a in aids if a not in prio]
        rng.shuffle(rest)
        gone = set((prio + rest)[:n])
        keep = sorted([r for r in recs if r["aid"] not in gone], key=lambda x: x["seq"])
        for s, r in enumerate(keep):                   # close the seq gaps; aids stay (ledger-bound)
            r["seq"] = s
        chain_sign(keep, run_id)
        return keep
    if fam == "B1_retry_duplicates":
        dup = [dict(r, t_arr=round(r["t_arr"] + rng.uniform(0.1, 1.0), 4)) for r in recs if rng.random() < p]
        return recs + dup
    if fam == "B2_async_reorder":
        for r in recs:
            if rng.random() < p:
                r["t_arr"] = round(r["t_ev"] + rng.uniform(0.0, 1.5), 4)
        return recs
    if fam == "B3_clock_skew":
        off = round(-p * 0.4, 4)                        # emitter clock behind, |off| <= 0.24 s < SKEW_TOL
        for r in recs:
            r["t_ev"] = round(r["t_ev"] + off, 4)
        chain_sign(recs, run_id)                        # emitter signs its own (skewed) clock
        return recs
    if fam == "B4_key_rotation":
        cut = int(len(recs) * (1 - p))
        for r in sorted(recs, key=lambda x: x["seq"])[cut:]:
            r["key_id"] = "k2"
        chain_sign(recs, run_id)
        return recs
    raise ValueError(fam)


# ---------------------------------------------------------------- estimator (no ground truth)
def estimate(recs, run_id, control_total, ledger_sample, rng,
             use_control_total=True, use_fid_sample=True, use_binding=True):
    # exact-duplicate removal (idempotent retries)
    seen, uniq = set(), []
    for r in sorted(recs, key=lambda x: x["t_arr"]):
        k = (r["run"], r["aid"], r["span"], r["mac"])
        if k not in seen:
            seen.add(k)
            uniq.append(r)
    by_mac = {r["mac"][:16]: r for r in uniq}
    valid = []
    for r in uniq:
        ok = mac_ok(r)
        if ok and use_binding:
            # context binding: record must belong to this run; where the predecessor is present,
            # the hash link must point to seq-1 (a missing predecessor is a coverage gap, not a breach)
            ok = r["run"] == run_id
            if ok and r["prev"] in by_mac:
                ok = by_mac[r["prev"]]["seq"] == r["seq"] - 1
        r["_valid"] = ok
        if ok:
            valid.append(r)
    own = [r for r in uniq if r["run"] == run_id]
    present = {(r["aid"], r["span"]) for r in own}
    aids_seen = [r["aid"] for r in own]
    if use_control_total:
        expected = len(SPANS) * control_total
    else:
        expected = len(SPANS) * ((max(aids_seen) + 1) if aids_seen else 0)
    C = min(1.0, len(present) / expected) if expected else 0.0
    I = len(valid) / len(uniq) if uniq else 0.0
    T = sum(1 for r in uniq if (r["t_arr"] - r["t_ev"]) <= BUDGET + SKEW_TOL) / len(uniq) if uniq else 0.0
    if use_fid_sample:
        out = {r["aid"]: r for r in valid if r["span"] == "OUTCOME"}
        comp = match = 0
        for aid, (payee, amount, _) in ledger_sample:
            if aid in out:
                comp += 1
                match += int(out[aid]["payee"] == payee and abs(out[aid]["amount"] - amount) < 0.01)
        # conditional fidelity: matches among sampled actions with a valid outcome record present;
        # absent records are penalised by coverage. If none is present, F is undefined and set to 0
        # (conservative convention; never triggered in the reported runs).
        F = match / comp if comp else 0.0
        F_uncond = match / len(ledger_sample) if ledger_sample else 0.0   # sensitivity only
    else:
        F, comp, F_uncond = 1.0, 0, 1.0
    return {"C": C, "F": F, "I": I, "T": T, "F_n": comp, "F_uncond": F_uncond}, valid


def aggregators(d):
    C, F, I, T = d["C"], d["F"], d["I"], d["T"]
    geo = (max(C, 0) * max(F, 0) * max(I, 0) * max(T, 0)) ** 0.25
    return {"arith": (C + F + I + T) / 4, "geo": geo, "min": min(C, F, I, T),
            "goi_gated": geo * (I if I < I_MIN else 1.0),          # implied by the published worked example
            "goi_hardgate": geo if I >= I_MIN else 0.0}


# ---------------------------------------------------------------- prior binary verifier (baseline)
def binary_verifier(recs, run_id, ledger):
    """Run-level conjunction of the eight check classes used in the earlier local testbed."""
    flags = set()
    seen = {}
    for r in recs:
        k = (r["aid"], r["span"])
        if k in seen:
            flags.add("duplicate_span")
        seen[k] = r
        if not mac_ok(r) or r["run"] != run_id:
            flags.add("integrity")
        if r.get("t_ev") is None:
            flags.add("missing_timestamp")
        elif r["t_arr"] - r["t_ev"] > BUDGET:
            flags.add("timeliness")
    aids = {r["aid"] for r in recs}
    for a in aids:
        if any((a, s) not in seen for s in SPANS):
            flags.add("coverage")
    seqs = sorted(r["seq"] for r in recs if r["run"] == run_id)
    if seqs and seqs[-1] - seqs[0] + 1 != len(set(seqs)):
        flags.add("coverage")
    arr = sorted([r for r in recs if r["run"] == run_id], key=lambda x: x["t_arr"])
    if any(arr[i]["seq"] > arr[i + 1]["seq"] for i in range(len(arr) - 1)):
        flags.add("reordered_spans")
    for r in recs:
        if r["span"] == "OUTCOME" and r["decision"] == "commit" and r["aid"] in ledger:
            p, a, _ = ledger[r["aid"]]
            if r["payee"] != p or abs(r["amount"] - a) > 0.01:
                flags.add("fidelity")
    return flags


# ---------------------------------------------------------------- criteria (ground truth only)
def criteria(valid, ledger, episodes):
    claims = {}
    for r in valid:
        if r["span"] == "OUTCOME" and r["decision"] == "commit":
            gaid = r.get("orig_aid", r["aid"])
            claims[r["aid"]] = (gaid, r["payee"], r["amount"])
    gt = {(aid, p, a) for aid, (p, a, _) in ledger.items()}
    cl = set(claims.values())
    # an insider-renumbered record is "correct" only if it matches the true action it came from
    correct = len(gt & cl)
    R = correct / len(gt | cl) if (gt | cl) else 1.0
    U = (len(cl - gt) / len(cl)) if cl else 0.0
    # online structuring monitor on accepted OUTCOME commits, processed in arrival order
    commits = sorted([r for r in valid if r["span"] == "OUTCOME" and r["decision"] == "commit"],
                     key=lambda x: x["t_arr"])
    hist, alerts = {}, []
    for r in commits:
        h = hist.setdefault(r["payee"], [])
        h.append(r)
        win = [x for x in h if abs(r["t_ev"] - x["t_ev"]) <= WINDOW and BAND * LIMIT <= x["amount"] <= LIMIT]
        if BAND * LIMIT <= r["amount"] <= LIMIT and len(win) >= 3:
            alerts.append((r["t_arr"], {x.get("orig_aid", x["aid"]) for x in win}))
    detected = timely = 0
    for e, members in episodes.items():
        last_t = max(ledger[a][2] for a in members)
        hits = [t for t, s in alerts if len(s & set(members)) >= 2]
        if hits:
            detected += 1
            if min(hits) - last_t <= BUDGET + 0.5:
                timely += 1
    fp_alerts = sum(1 for _, s in alerts
                    if not any(len(s & set(m)) >= 2 for m in episodes.values()))
    return {"R": R, "U": U, "ep": len(episodes), "ep_detected": detected,
            "ep_timely": timely, "monitor_fp_alerts": fp_alerts, "n_alerts": len(alerts)}


# ---------------------------------------------------------------- one run
def run_once(seed, faults, ablate=False):
    """faults: list of (family, severity). Returns flat dict."""
    rng = random.Random(seed)
    run_id = f"R{seed}"
    emit = next(((f, p) for f, p in faults if f == "F2_fidelity_bug"), None)
    actions, ledger, episodes, recs = gen_world(rng, run_id, emit)
    _, _, _, donor = gen_world(random.Random(seed + 7_919), f"R{seed}-donor")
    # stage order: emitter-side (B3, B4) -> key-holding insider (H3, H4) -> transport path
    stage = {"B3_clock_skew": 0, "B4_key_rotation": 0, "H3_insider_forgery": 1, "H4_insider_deletion": 1}
    for fam, p in sorted(faults, key=lambda fp: stage.get(fp[0], 2)):
        recs = apply_fault(fam, p, recs, rng, run_id, ledger, episodes, donor)
    control_total = len(actions)                      # independent gateway counter
    srng = random.Random(seed * 31 + 1)
    sample = srng.sample(sorted(ledger.items()), min(FID_SAMPLE, len(ledger)))
    sample = [(aid, v) for aid, v in sample]
    est, valid = estimate([dict(r) for r in recs], run_id, control_total, sample, srng)
    row = {"seed": seed}
    row.update(est)
    row.update(aggregators(est))
    row.update(criteria(valid, ledger, episodes))
    bv = binary_verifier(recs, run_id, ledger)
    row["bv_fail"] = int(bool(bv))
    row["bv_flags"] = ";".join(sorted(bv))
    if ablate:
        for name, kw in (("noCT", dict(use_control_total=False)),
                         ("noFS", dict(use_fid_sample=False)),
                         ("noBind", dict(use_binding=False))):
            e2, v2 = estimate([dict(r) for r in recs], run_id, control_total, sample, srng, **kw)
            row[f"{name}_goi"] = aggregators(e2)["goi_gated"]
            row[f"{name}_C"], row[f"{name}_F"], row[f"{name}_I"] = e2["C"], e2["F"], e2["I"]
            row[f"{name}_U"] = criteria(v2, ledger, episodes)["U"]
    return row


# ---------------------------------------------------------------- experiments
def main(out="results"):
    os.makedirs(out, exist_ok=True)
    rows = []
    # E1: dose-response, single family x severity x 30 seeds
    sid = 0
    for fam in FAMILIES:
        for p in SEVERITIES:
            for rep in range(30):
                sid += 1
                seed = MASTER_SEED + sid
                r = run_once(seed, [(fam, p)])
                r.update({"exp": "E1", "family": fam, "p": p})
                rows.append(r)
    # E2: random mixtures for criterion validity (held-out families included; benign always on)
    mrng = random.Random(MASTER_SEED)
    for i in range(1000):
        seed = MASTER_SEED + 100_000 + i
        faults = []
        for fam in KNOWN + HELDOUT:
            if mrng.random() < 0.25:
                faults.append((fam, round(mrng.uniform(0.01, 0.30), 3)))
        for fam in BENIGN:
            faults.append((fam, round(mrng.uniform(0.0, 0.3), 3)))
        # emitter-side fault must be resolved before telemetry faults; order otherwise as listed
        r = run_once(seed, faults, ablate=True)
        r.update({"exp": "E2", "family": "+".join(f for f, _ in faults if f not in BENIGN) or "none",
                  "p": max([p for f, p in faults if f not in BENIGN] or [0.0])})
        for f, p in faults:
            r["sev_" + f] = p
        rows.append(r)
    keys = sorted({k for r in rows for k in r})
    with open(os.path.join(out, "runs.csv"), "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=keys)
        w.writeheader()
        for r in rows:
            w.writerow(r)
    src = open(__file__, "rb").read()
    meta = {"version": "1.0.1", "master_seed": MASTER_SEED, "n_rows": len(rows),
            "script_sha256": hashlib.sha256(src).hexdigest(),
            "params": {"LIMIT": LIMIT, "BUDGET": BUDGET, "SKEW_TOL": SKEW_TOL, "N_ACTIONS": N_ACTIONS,
                       "FID_SAMPLE": FID_SAMPLE, "I_MIN": I_MIN, "WINDOW": WINDOW,
                       "N_EPISODES": N_EPISODES, "BAND": BAND, "SEVERITIES": SEVERITIES},
            "python": sys.version.split()[0]}
    json.dump(meta, open(os.path.join(out, "manifest.json"), "w"), indent=2)
    print(json.dumps(meta, indent=2))


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "results")
