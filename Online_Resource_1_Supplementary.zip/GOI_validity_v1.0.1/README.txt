GOI criterion-validity study v1.0.1
Reproduce: python3 goi_testbed.py results && python3 analyse.py results
Requires: Python 3.10+, numpy, pandas, scipy, matplotlib
Master seed: 20261029. Script hashes in results/manifest.json. Keys are test-only literals.
v1.0.1: adds per-run fields F_n and F_uncond (fidelity-definition sensitivity); all v1.0 fields identical.
