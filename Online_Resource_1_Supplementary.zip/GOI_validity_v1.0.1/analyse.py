#!/usr/bin/env python3
"""Analysis and figures for the GOI measurement-validation study. Reads results/runs.csv."""
import json
import os
import sys
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

RES = sys.argv[1] if len(sys.argv) > 1 else "results"
FIG = os.path.join(RES, "figs")
os.makedirs(FIG, exist_ok=True)
df = pd.read_csv(os.path.join(RES, "runs.csv"))
df["timely"] = df["ep_timely"] / df["ep"]
df["detected"] = df["ep_detected"] / df["ep"]
out = {}

S = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#6250d6"]
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e4e3df"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": INK2,
                     "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2,
                     "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True,
                     "grid.color": GRID, "grid.linewidth": 0.6, "lines.linewidth": 2,
                     "savefig.dpi": 300, "figure.facecolor": "white"})
LABEL = {"F1_drop": "F1 Random record loss", "F2_fidelity_bug": "F2 Emitter fidelity bug",
         "F3_tamper": "F3 Post-signing tampering", "F4_delay": "F4 Late delivery",
         "H1_tail_truncation": "H1 Tail truncation", "H2_replay": "H2 Cross-run replay",
         "H3_insider_forgery": "H3 Key-holder forgery", "H4_insider_deletion": "H4 Key-holder deletion",
         "B1_retry_duplicates": "B1 Idempotent retries", "B2_async_reorder": "B2 Asynchronous reordering",
         "B3_clock_skew": "B3 Clock skew (in tolerance)", "B4_key_rotation": "B4 Key rotation"}


def boot_ci(x, y, f, n=2000, seed=1):
    rng = np.random.default_rng(seed)
    x, y = np.asarray(x), np.asarray(y)
    vals = []
    for _ in range(n):
        i = rng.integers(0, len(x), len(x))
        vals.append(f(x[i], y[i]))
    return float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))


def auc(score_bad_low, bad):
    """AUC that a low score identifies a bad run (Mann-Whitney)."""
    s = -np.asarray(score_bad_low)
    b = np.asarray(bad).astype(bool)
    pos, neg = s[b], s[~b]
    if len(pos) == 0 or len(neg) == 0:
        return float("nan")
    ranks = pd.Series(np.concatenate([pos, neg])).rank().values
    return float((ranks[:len(pos)].sum() - len(pos) * (len(pos) + 1) / 2) / (len(pos) * len(neg)))


# ---------------------------------------------------------------- 1. analytic gate behaviour
def goi_gated(c, f, i, t, imin=0.5):
    g = (c * f * i * t) ** 0.25
    return g * (i if i < imin else 1.0)


I = np.linspace(0.0, 1.0, 1001)
base = 0.95
curves = {"Arithmetic mean": (3 * base + I) / 4,
          "Geometric mean": (base ** 3 * I) ** 0.25,
          "Minimum": np.minimum(base, I),
          "Gated GOI (g(I)=I below floor)": np.array([goi_gated(base, base, i, base) for i in I])}
just_below = goi_gated(base, base, 0.4999, base)
at = goi_gated(base, base, 0.5, base)
out["gate"] = {"worked_example_0.30": round(goi_gated(.95, .95, .30, .95), 3),
               "geo_at_0.30": round((.95 ** 3 * .3) ** .25, 3),
               "arith_at_0.30": round((3 * .95 + .3) / 4, 3),
               "just_below_floor": round(just_below, 3), "at_floor": round(at, 3),
               "jump": round(at - just_below, 3),
               "geo_C_only": {str(c): round(c ** 0.25, 3) for c in (0.9, 0.8, 0.7, 0.6, 0.5)}}
fig, ax = plt.subplots(figsize=(6.3, 3.4))
for (k, v), col in zip(curves.items(), S):
    ax.plot(I, v, color=col, label=k)
ax.axvline(0.5, color=INK2, lw=0.8, ls=":")
ax.annotate(f"jump {at - just_below:.2f}\nat I = 0.5", xy=(0.5, (at + just_below) / 2), xytext=(0.30, 0.55),
            fontsize=8, color=INK, arrowprops=dict(arrowstyle="-", color=INK2, lw=0.7))
ax.set_xlabel("Integrity I (coverage = fidelity = timeliness = 0.95)")
ax.set_ylabel("Aggregate score")
ax.set_xlim(0, 1); ax.set_ylim(0, 1.02)
ax.legend(frameon=False, fontsize=8, loc="lower right")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig2_aggregators.png")); plt.close(fig)

# ---------------------------------------------------------------- 2. E1 dose-response
e1 = df[df.exp == "E1"].copy()
g = e1.groupby(["family", "p"]).agg(C=("C", "mean"), F=("F", "mean"), I=("I", "mean"), T=("T", "mean"),
                                    GOI=("goi_gated", "mean"), GOI_sd=("goi_gated", "std"),
                                    R=("R", "mean"), U=("U", "mean"), timely=("timely", "mean"),
                                    bv=("bv_fail", "mean"), n=("seed", "count")).reset_index()
g.to_csv(os.path.join(RES, "e1_summary.csv"), index=False)
clean = e1[e1.p == 0]
out["clean"] = {"n": int(len(clean)), "goi_mean": float(clean.goi_gated.mean()), "goi_min": float(clean.goi_gated.min()),
                "R_mean": float(clean.R.mean()), "bv_fail_rate": float(clean.bv_fail.mean()),
                "structuring_episodes": int(clean.ep.sum()), "episodes_committed_by_gateway": int(clean.ep.sum()),
                "monitor_timely_recall": float(clean.ep_timely.sum() / clean.ep.sum()),
                "monitor_fp_alerts_per_run": float(clean.monitor_fp_alerts.mean())}
tab = []
for fam in LABEL:
    for p in (0.05, 0.30):
        r = g[(g.family == fam) & (np.isclose(g.p, p))].iloc[0]
        sub = e1[(e1.family == fam) & np.isclose(e1.p, p)]
        tab.append({"family": fam, "p": p, "C": r.C, "F": r.F, "I": r.I, "T": r["T"], "GOI": r.GOI,
                    "R": r.R, "U": r.U, "timely": r.timely, "bv_fail": r.bv,
                    "goi_below_1": float((sub.goi_gated < 0.999).mean())})
tab = pd.DataFrame(tab)
tab.to_csv(os.path.join(RES, "table_e1.csv"), index=False)
out["e1_table"] = tab.round(3).to_dict(orient="records")
# probability fidelity sample flags key-holder forgery
h3 = e1[e1.family == "H3_insider_forgery"].groupby("p").apply(lambda s: float((s.F < 1).mean()), include_groups=False)
out["h3_flag_rate_by_p"] = {str(k): round(v, 3) for k, v in h3.items()}
out["h3_timely_by_p"] = {str(k): round(v, 3) for k, v in
                         e1[e1.family == "H3_insider_forgery"].groupby("p").timely.mean().items()}
out["h3_goi_by_p"] = {str(k): round(v, 3) for k, v in
                      e1[e1.family == "H3_insider_forgery"].groupby("p").goi_gated.mean().items()}

fig, axes = plt.subplots(3, 4, figsize=(7.2, 6.4), sharex=True, sharey=True)
for ax, fam in zip(axes.ravel(), LABEL):
    s = g[g.family == fam]
    ax.plot(s.p, s.GOI, color=S[0], label="Gated GOI (estimated)")
    ax.plot(s.p, s.R, color=S[1], ls="--", label="Reconstruction accuracy R (ground truth)")
    ax.plot(s.p, s.timely, color=S[2], ls=":", label="Timely monitor recall (ground truth)")
    ax.set_title(LABEL[fam], fontsize=7.5, color=INK, loc="left")
    ax.set_ylim(-0.03, 1.05); ax.set_xticks([0, 0.2, 0.4, 0.6])
for ax in axes[-1]:
    ax.set_xlabel("Severity p", fontsize=8)
for ax in axes[:, 0]:
    ax.set_ylabel("Score / rate", fontsize=8)
h, l = axes[0, 0].get_legend_handles_labels()
fig.legend(h, l, loc="lower center", ncol=3, frameon=False, fontsize=7.5)
fig.tight_layout(rect=(0, 0.05, 1, 1)); fig.savefig(os.path.join(FIG, "fig3_dose_response.png")); plt.close(fig)

# ---------------------------------------------------------------- 3. E2 criterion validity
e2 = df[df.exp == "E2"].copy()
e2["bad"] = (e2.R < 0.90) | (e2.U > 0.02)
e2["has_H3"] = e2["sev_H3_insider_forgery"].fillna(0) > 0
crit = {"R": "R", "1-U": None, "timely": "timely"}
rows = []
scores = {"Arithmetic": "arith", "Geometric": "geo", "Minimum": "min", "Gated GOI": "goi_gated",
          "Hard-gated GOI": "goi_hardgate", "Coverage only": "C", "Fidelity only": "F",
          "Integrity only": "I", "Timeliness only": "T"}
rho = lambda a, b: spearmanr(a, b).statistic
for name, col in scores.items():
    x = e2[col].values
    rec = {"score": name}
    for cn, cc in (("R", e2.R.values), ("1-U", 1 - e2.U.values), ("timely", e2.timely.values)):
        rec[f"rho_{cn}"] = rho(x, cc)
        lo, hi = boot_ci(x, cc, rho, n=1000)
        rec[f"rho_{cn}_ci"] = (lo, hi)
    rec["auc_bad"] = auc(x, e2.bad.values)
    rows.append(rec)
val = pd.DataFrame(rows)
val.to_csv(os.path.join(RES, "table_validity.csv"), index=False)
out["e2"] = {"n": int(len(e2)), "bad_rate": float(e2.bad.mean()),
             "validity": [{k: (round(v, 3) if isinstance(v, float) else
                               ([round(z, 3) for z in v] if isinstance(v, tuple) else v)) for k, v in r.items()}
                          for r in rows]}
# high-GOI blind spot
hi = e2[e2.goi_gated >= 0.90]
out["e2_high_goi"] = {"n": int(len(hi)), "bad_share": float(hi.bad.mean()),
                      "R_min": float(hi.R.min()), "U_max": float(hi.U.max()),
                      "timely_lt1_share": float((hi.timely < 1).mean()),
                      "share_bad_with_H3": float(hi[hi.bad].has_H3.mean()) if hi.bad.any() else None}
# ablations
ab = {}
for name, col, ucol in (("full", "goi_gated", "U"), ("no control total", "noCT_goi", "noCT_U"),
                        ("no fidelity sample", "noFS_goi", "noFS_U"), ("no context binding", "noBind_goi", "noBind_U")):
    ab[name] = {"rho_R": round(rho(e2[col], e2.R), 3), "rho_1-U": round(rho(e2[col], 1 - e2[ucol]), 3),
                "auc_bad": round(auc(e2[col], e2.bad), 3), "mean_U_accepted": round(float(e2[ucol].mean()), 4)}
h1 = e2["sev_H1_tail_truncation"].fillna(0) > 0
ab["coverage_error_on_H1_runs"] = {"full": round(float((e2[h1].C - e2[h1].R).abs().mean()), 3),
                                   "no control total": round(float((e2[h1].noCT_C - e2[h1].R).abs().mean()), 3)}
h2 = e2["sev_H2_replay"].fillna(0) > 0
ab["U_on_H2_runs"] = {"full": round(float(e2[h2].U.mean()), 4), "no context binding": round(float(e2[h2].noBind_U.mean()), 4)}
out["ablation"] = ab

fig, ax = plt.subplots(figsize=(6.3, 3.6))
nh = e2[~e2.has_H3]; yh = e2[e2.has_H3]
ax.scatter(nh.goi_gated, nh.R, s=10, color=S[0], alpha=0.55, edgecolor="white", linewidth=0.3,
           label="Runs without key-holder forgery")
ax.scatter(yh.goi_gated, yh.R, s=10, color=S[1], alpha=0.75, edgecolor="white", linewidth=0.3,
           label="Runs with key-holder forgery (H3)")
ax.axvline(0.9, color=INK2, lw=0.8, ls=":")
ax.set_xlabel("Gated GOI (estimated from telemetry)")
ax.set_ylabel("Reconstruction accuracy R (ground truth)")
ax.legend(frameon=False, fontsize=8, loc="upper left")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig4_validity_scatter.png")); plt.close(fig)

# ---------------------------------------------------------------- 4. binary verifier vs GOI on benign
bvt = []
for fam in LABEL:
    for p in (0.05, 0.30):
        sub = e1[(e1.family == fam) & np.isclose(e1.p, p)]
        bvt.append({"family": fam, "p": p, "bv_fail": float(sub.bv_fail.mean()),
                    "goi_mean": float(sub.goi_gated.mean()), "R_mean": float(sub.R.mean())})
out["bv"] = bvt
out["gate_activation"] = {"E1_share_I_below_floor": float((e1.I < 0.5).mean()),
                          "E1_F3_p_min_with_activation": float(e1[(e1.family == "F3_tamper") & (e1.I < 0.5)].p.min()) if ((e1.family == "F3_tamper") & (e1.I < 0.5)).any() else None,
                          "E2_share_I_below_floor": float((e2.I < 0.5).mean()),
                          "E2_I_min": float(e2.I.min())}
out["e2_none_share"] = float((e2.family == "none").mean())

# ---------------------------------------------------------------- 5. architecture schematic
fig, ax = plt.subplots(figsize=(7.0, 3.3)); ax.set_axis_off(); ax.set_xlim(0, 10.25); ax.set_ylim(0, 5)
def box(x, y, w, h, t, fc="#f4f3f0", ec=INK2):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.04,rounding_size=0.12", fc=fc, ec=ec, lw=0.9))
    ax.text(x + w / 2, y + h / 2, t, ha="center", va="center", fontsize=7.5, color=INK)
def arr(x1, y1, x2, y2, t=None, ls="-"):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle="->", color=INK2, lw=0.9, ls=ls))
    if t: ax.text((x1 + x2) / 2, (y1 + y2) / 2 + 0.12, t, ha="center", fontsize=6.5, color=INK2)
box(0.1, 3.6, 1.7, 0.9, "Synthetic intents\n(incl. structuring)")
box(2.3, 3.6, 1.7, 0.9, "Policy gateway\n(per-action rules)")
box(4.5, 3.6, 1.7, 0.9, "Authoritative\nmock ledger", fc="#e8f0fb")
box(2.3, 1.9, 1.7, 0.9, "Signed telemetry\n(HMAC + hash chain)")
box(4.5, 1.9, 1.7, 0.9, "Fault and benign-\nperturbation injector")
box(6.7, 1.9, 1.5, 0.9, "GOI estimator\n(C, F, I, T)")
box(8.4, 1.9, 1.5, 0.9, "Aggregators\n+ monitor")
box(6.7, 0.2, 3.2, 0.9, "Criterion scoring: R, U, timely recall\n(ground truth; never seen by estimator)", fc="#e8f0fb")
arr(1.8, 4.05, 2.3, 4.05); arr(4.0, 4.05, 4.5, 4.05)
arr(3.15, 3.6, 3.15, 2.8, "spans"); arr(4.0, 2.35, 4.5, 2.35); arr(6.2, 2.35, 6.7, 2.35); arr(8.2, 2.35, 8.4, 2.35)
arr(6.2, 3.8, 7.45, 2.8, None, ls="--"); ax.text(6.95, 3.45, "control total;\nn = 40 sample", ha="left", fontsize=6.5, color=INK2)
ax.plot([6.2, 10.1, 10.1], [4.25, 4.25, 0.65], color=INK2, lw=0.9, ls=":")
arr(10.1, 0.65, 9.95, 0.65, None, ls=":")
ax.text(8.0, 4.35, "ground truth (criterion only)", ha="center", fontsize=6.5, color=INK2)
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig1_testbed.png")); plt.close(fig)

json.dump(out, open(os.path.join(RES, "summary.json"), "w"), indent=1, default=float)
print(json.dumps(out, indent=1, default=float))

# ---------------------------------------------------------------- 6. decision rules (appended)
def rule_stats(flag, bad):
    flag, bad = np.asarray(flag, bool), np.asarray(bad, bool)
    return {"sens": round(float((flag & bad).sum() / bad.sum()), 3),
            "spec": round(float((~flag & ~bad).sum() / (~bad).sum()), 3),
            "flag_rate": round(float(flag.mean()), 3)}
rules = {}
for tau in (0.90, 0.95, 0.98):
    rules[f"GOI < {tau}"] = rule_stats(e2.goi_gated < tau, e2.bad)
for fl in (0.90, 0.95):
    rules[f"any dimension < {fl}"] = rule_stats(e2[["C", "F", "I", "T"]].min(axis=1) < fl, e2.bad)
# Youden-optimal GOI threshold
best = max(((t, (lambda s: s["sens"] + s["spec"] - 1)(rule_stats(e2.goi_gated < t, e2.bad)))
            for t in np.round(np.arange(0.80, 1.0001, 0.0025), 4)), key=lambda z: z[1])
rules["youden_opt_tau"] = {"tau": float(best[0]), **rule_stats(e2.goi_gated < best[0], e2.bad)}
out["rules"] = rules
out["equiv_single_dim_for_goi"] = {str(t): round(t ** 4, 3) for t in (0.95, 0.90, 0.85)}
json.dump(out, open(os.path.join(RES, "summary.json"), "w"), indent=1, default=float)
print("RULES", json.dumps(rules))

# ---------------------------------------------------------------- 7. fidelity-definition sensitivity (v1.0.1)
def gated(c, f, i, t):
    g = (c * f * i * t) ** 0.25
    return g * np.where(i < 0.5, i, 1.0)
e2["goi_uncondF"] = gated(e2.C, e2.F_uncond, e2.I, e2["T"])
sens = {"conditional (reported)": {"rho_R": round(rho(e2.goi_gated, e2.R), 3), "auc_bad": round(auc(e2.goi_gated, e2.bad), 3),
                                   "rho_1-U_F": round(rho(e2.F, 1 - e2.U), 3)},
        "unconditional (missing = mismatch)": {"rho_R": round(rho(e2.goi_uncondF, e2.R), 3), "auc_bad": round(auc(e2.goi_uncondF, e2.bad), 3),
                                               "rho_1-U_F": round(rho(e2.F_uncond, 1 - e2.U), 3)},
        "F_n_all_runs": {"min": int(df.F_n.min()), "median": float(df.F_n.median()), "runs_F_n_0": int((df.F_n == 0).sum()),
                         "runs_F_n_lt_30": int((df.F_n < 30).sum())},
        "rho_C_Funcond_E2": round(rho(e2.C, e2.F_uncond), 3), "rho_C_F_E2": round(rho(e2.C, e2.F), 3)}
out["fidelity_sensitivity"] = sens
json.dump(out, open(os.path.join(RES, "summary.json"), "w"), indent=1, default=float)
print("FSENS", json.dumps(sens))
