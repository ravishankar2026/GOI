Online Resource 1 — Supplementary Materials
Journal: UAEU Journal of Engineering

Manuscript:
Does an Integrity-Gated Governance Observability Index Measure Reconstructability?
A Criterion-Validity Study of Agent Telemetry under Out-of-Specification Faults

Contents:
- goi_testbed.py: deterministic synthetic fault-injection testbed
- analyse.py: analysis and output generation
- results/runs.csv: run-level dataset (3,520 rows)
- results/manifest.json: hashes and run metadata
- summary outputs, tables and figures

Reproduction (run from the GOI_validity_v1.0.1 directory):
python3 goi_testbed.py results
python3 analyse.py results

Master seed: 20261029.
The scripts and data are supplied for review. No public repository DOI has been assigned.
